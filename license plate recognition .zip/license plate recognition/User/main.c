#include "./SYSTEM/sys/sys.h"
#include "./SYSTEM/usart/usart.h"
#include "./SYSTEM/delay/delay.h"
#include "./BSP/LED/led.h"
#include "./BSP/LCD/lcd.h"
#include "./BSP/LCD/ltdc.h"
#include "./BSP/SDRAM/sdram.h"
#include "./BSP/PLATE/plate_main.h"

int main(void)
{
    sys_stm32_clock_init(360, 25, 2, 8);
    delay_init(180);
    usart_init(45, 115200);
    led_init();
    sdram_init();
    lcd_init();
    key_init();
    
    plate_recognition_test();  /* ���᷵�� */
}