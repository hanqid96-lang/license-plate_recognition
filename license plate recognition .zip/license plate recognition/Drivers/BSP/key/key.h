/**
 ****************************************************************************************************
 * @file        key.h
 * @brief       ��������ͷ�ļ�
 *              KEY0-PH3  KEY1-PH2  KEY2-PC13  WK_UP-PA0
 ****************************************************************************************************
 */
#ifndef __KEY_H
#define __KEY_H

#include "./SYSTEM/sys/sys.h"

/*---------------------- ���Ŷ��� ----------------------*/
/* KEY0 - PH3 */
#define KEY0_GPIO_PORT      GPIOH
#define KEY0_GPIO_PIN       (1 << 3)
#define KEY0_GPIO_CLK_EN()  do{ RCC->AHB1ENR |= (1 << 7); }while(0)  /* GPIOHʱ�� */

/* KEY1 - PH2 */
#define KEY1_GPIO_PORT      GPIOH
#define KEY1_GPIO_PIN       (1 << 2)
#define KEY1_GPIO_CLK_EN()  do{ RCC->AHB1ENR |= (1 << 7); }while(0)

/* KEY2 - PC13 */
#define KEY2_GPIO_PORT      GPIOC
#define KEY2_GPIO_PIN       (1 << 13)
#define KEY2_GPIO_CLK_EN()  do{ RCC->AHB1ENR |= (1 << 2); }while(0)  /* GPIOCʱ�� */

/* WK_UP - PA0 */
#define WKUP_GPIO_PORT      GPIOA
#define WKUP_GPIO_PIN       (1 << 0)
#define WKUP_GPIO_CLK_EN()  do{ RCC->AHB1ENR |= (1 << 0); }while(0)  /* GPIOAʱ�� */

/*---------------------- ��ȡ���ŵ�ƽ ----------------------*/
#define KEY0_READ()         ((KEY0_GPIO_PORT->IDR & KEY0_GPIO_PIN) ? 1 : 0)
#define KEY1_READ()         ((KEY1_GPIO_PORT->IDR & KEY1_GPIO_PIN) ? 1 : 0)
#define KEY2_READ()         ((KEY2_GPIO_PORT->IDR & KEY2_GPIO_PIN) ? 1 : 0)
#define WKUP_READ()         ((WKUP_GPIO_PORT->IDR & WKUP_GPIO_PIN) ? 1 : 0)

/*---------------------- ����ֵ���� ----------------------*/
#define KEY0_PRESSED        1
#define KEY1_PRESSED        2
#define KEY2_PRESSED        3
#define WKUP_PRESSED        4

/*---------------------- �������� ----------------------*/
void    key_init(void);
uint8_t key_scan(uint8_t mode);

/*---------------------- ����ԭ���������� ----------------------*/
#define KEY0_PRES   KEY0_PRESSED
#define KEY1_PRES   KEY1_PRESSED
#define KEY2_PRES   KEY2_PRESSED
#define WKUP_PRES   WKUP_PRESSED

#endif