#include "./BSP/WIFI/wifi.h"
#include "./SYSTEM/delay/delay.h"
#include "./SYSTEM/usart/usart.h"

uint8_t wifi_send_at(char *cmd, char *expect, uint16_t timeout_ms)
{
    uart3_clear_buf();
    uart3_send_string(cmd);

    while (timeout_ms--)
    {
        delay_ms(1);

        if (wifi_rx_done)
        {
            if (strstr((char *)wifi_rx_buf, expect) != NULL)
            {
                return 1;
            }
            if (strstr((char *)wifi_rx_buf, "ERROR") != NULL)
            {
                return 0;
            }
        }
    }
    return 0;
}

uint8_t wifi_connect(char *ssid, char *password)
{
    char cmd[128];

    wifi_send_at("AT+CWQAP\r\n", "OK", 3000);
    delay_ms(1000);

    sprintf(cmd, "AT+CWJAP=\"%s\",\"%s\"\r\n", ssid, password);
    uart3_clear_buf();
    uart3_send_string(cmd);

    uint16_t timeout = 30000;
    while (timeout--)
    {
        delay_ms(1);

        if (wifi_rx_done)
        {
            if (strstr((char *)wifi_rx_buf, "GOT IP") != NULL ||
                strstr((char *)wifi_rx_buf, "OK") != NULL)
            {
                delay_ms(2000);
                return 1;
            }
            if (strstr((char *)wifi_rx_buf, "FAIL") != NULL ||
                strstr((char *)wifi_rx_buf, "ERROR") != NULL)
            {
                return 0;
            }
        }
    }
    return 0;
}

void wifi_init(void)
{
    uart3_init(45, 115200);

    delay_ms(3000);

    wifi_send_at("AT\r\n",          "OK", 2000);
    wifi_send_at("AT\r\n",          "OK", 2000);
    wifi_send_at("AT\r\n",          "OK", 2000);
    wifi_send_at("ATE0\r\n",        "OK", 2000);
    wifi_send_at("AT+CWMODE=1\r\n", "OK", 2000);
    wifi_send_at("AT+CWDHCP=1,1\r\n","OK", 2000);
}
