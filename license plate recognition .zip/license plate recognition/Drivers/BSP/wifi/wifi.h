#ifndef __WIFI_H
#define __WIFI_H

#include "./SYSTEM/sys/sys.h"
#include "./BSP/UART3/uart3.h"
#include <stdio.h>
#include <string.h>

#define wifi_clear_buf()    uart3_clear_buf()

uint8_t wifi_send_at(char *cmd, char *expect, uint16_t timeout_ms);
uint8_t wifi_connect(char *ssid, char *password);
void    wifi_init(void);

#endif
