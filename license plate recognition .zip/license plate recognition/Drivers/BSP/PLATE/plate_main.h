#ifndef __PLATE_MAIN_H
#define __PLATE_MAIN_H

#include <stdint.h>

void plate_recognition_test(void);

#endif /* __PLATE_MAIN_H */