#ifndef __PLATE_DETECT_H
#define __PLATE_DETECT_H

#include <stdint.h>

typedef struct {
    uint16_t x, y;
    uint16_t w, h;
    uint8_t  valid;
} PlateRect;

typedef struct {
    uint16_t x, y;
    uint16_t w, h;
} CharRect;

void plate_locate(const uint16_t *frame,
                  uint16_t img_w, uint16_t img_h,
                  PlateRect *plate);

void plate_split_chars(const uint16_t *frame,
                       uint16_t img_w,
                       const PlateRect *plate,
                       CharRect chars[7],
                       uint8_t *char_count);

void plate_char_to_input(const uint16_t *frame,
                         uint16_t img_w,
                         const CharRect *cr,
                         float out_800[800]);

#endif