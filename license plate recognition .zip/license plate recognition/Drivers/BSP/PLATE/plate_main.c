/**
 * @file    plate_main.c
 * @brief   ����ʶ��������
 *          - ��KEY0���ղ�ʶ�𣬰�KEY1����Ԥ��
 *          - ����: UART5 (PD2=TX, PC12=RX)
 *          - 2.8��MCU�� 240��320
 *
 * ��Ļ����:
 *   0  ~ 159��: ����ͷԤ��(240��80�Ŵ�2����ʾΪ240��160)
 *   160~ 162��: �ָ���
 *   165~ 319��: ʶ���� / ������ʾ
 */

#include "./BSP/CAMERA/camera.h"
#include "./BSP/LCD/lcd.h"
#include "./BSP/KEY/key.h"
#include "./BSP/LED/led.h"
#include "./SYSTEM/delay/delay.h"
#include "./SYSTEM/usart/usart.h"
#include "./BSP/DCMI/dcmi.h"
#include "./BSP/OV5640/ov5640.h"
#include "./BSP/SDRAM/sdram.h"
#include "plate_detect.h"
#include "plate_infer.h"
#include <stdio.h>
#include <string.h>

/*==================== �궨�� ====================*/

/*
 * ���Ʊ����޸���
 * ���Ʊ�׼�ߴ� 440��140�����߱�Լ 3:1
 * ����ͷ��� 240��80�����߱� 3:1���복��һ�£�
 * ��ʾʱ�Ŵ�2���� 240��160
 */
#define IMG_W        240
#define IMG_H        80

#define LCD_W        240
#define LCD_H        320
#define PREVIEW_H    160    /* Ԥ�����߶ȣ��Ŵ�2���� */
#define RESULT_Y     170

/* SDRAM֡���� */
#define FRAME_BUF_ADDR   ((uint16_t *)(0xC0100000))
#define NN_INPUT_ADDR    ((float *)   (0xC0200000))

/*==================== ȫ�ֱ��� ====================*/

static uint16_t   *g_frame        = FRAME_BUF_ADDR;
static PlateResult g_plate_result;
static uint8_t     g_result_valid = 0;
static PlateRect   g_plate_rect;

typedef enum { STATE_PREVIEW, STATE_CAPTURE, STATE_RESULT } AppState;
static AppState g_state = STATE_PREVIEW;

/*==================== �������� ====================*/

static void draw_rect(uint16_t x, uint16_t y,
                      uint16_t w, uint16_t h, uint16_t color)
{
    /* ����ת����ԭͼ�����2 = ��Ļ���� */
    uint16_t sx = x;
    uint16_t sy = y * 2;
    uint16_t sw = w;
    uint16_t sh = h * 2;

    if (sx + sw >= LCD_W)    sw = LCD_W - sx - 2;
    if (sy + sh >= PREVIEW_H) sh = PREVIEW_H - sy - 2;

    lcd_fill(sx,      sy,      sx+sw,   sy+1,   color);
    lcd_fill(sx,      sy+sh,   sx+sw,   sy+sh+1,color);
    lcd_fill(sx,      sy,      sx+1,    sy+sh,  color);
    lcd_fill(sx+sw,   sy,      sx+sw+1, sy+sh,  color);
}

/**
 * @brief  ��֡����ˢ��LCD����ֱ����2���Ŵ�
 */
static void flush_preview(void)
{
    uint16_t y, x;
    uint16_t src_y;

    lcd_set_window(0, 0, IMG_W, PREVIEW_H);
    lcd_set_cursor(0, 0);
    lcd_write_ram_prepare();

    for (y = 0; y < PREVIEW_H; y++)
    {
        src_y = y / 2;   /* ��ֱ2���Ŵ� */
        for (x = 0; x < IMG_W; x++)
        {
            LCD->LCD_RAM = g_frame[(uint32_t)src_y * IMG_W + x];
        }
    }

    lcd_set_window(0, 0, LCD_W, LCD_H);
}

static void clear_result_area(void)
{
    lcd_fill(0, PREVIEW_H + 3, LCD_W - 1, LCD_H - 1, BLACK);
}

static void show_hint(void)
{
    clear_result_area();
    lcd_show_string(5, RESULT_Y,    LCD_W-10, 16, 16,
                    "KEY0: Capture", GREEN);
    lcd_show_string(5, RESULT_Y+22, LCD_W-10, 16, 16,
                    "KEY1: Preview", GRAY);
}

static void show_result(void)
{
    clear_result_area();

    if (!g_result_valid)
    {
        lcd_show_string(5, RESULT_Y,    LCD_W-10, 16, 16,
                        "No plate found!", RED);
        lcd_show_string(5, RESULT_Y+22, LCD_W-10, 16, 16,
                        "KEY0:Retry  KEY1:Back", GRAY);
        return;
    }

    /* ƴ�ӽ����������?���棩 */
    char buf[32] = {0};
    uint8_t bi = 0;
    for (uint8_t i = 0; i < g_plate_result.char_count && bi < 28; i++)
    {
        const char *c = g_plate_result.chars[i].char_utf8;
        buf[bi++] = ((uint8_t)c[0] > 127) ? '?' : c[0];
    }

    lcd_show_string(5, RESULT_Y,    LCD_W-10, 16, 16, "Plate:", GREEN);
    lcd_show_string(5, RESULT_Y+20, LCD_W-10, 16, 16, buf, WHITE);

    float avg = 0;
    for (uint8_t i = 0; i < g_plate_result.char_count; i++)
        avg += g_plate_result.chars[i].confidence;
    if (g_plate_result.char_count)
        avg /= g_plate_result.char_count;

    char cbuf[20];
    sprintf(cbuf, "Conf:%d%%", (int)(avg * 100));
    lcd_show_string(5, RESULT_Y+40, LCD_W-10, 12, 12, cbuf, CYAN);
    lcd_show_string(5, RESULT_Y+56, LCD_W-10, 12, 12,
                    "KEY0:Retry  KEY1:Back", GRAY);

    printf("[PLATE] %s  conf=%.1f%%\r\n",
           g_plate_result.plate_str, avg * 100.0f);
}

static void do_recognize(void)
{
    clear_result_area();
    lcd_show_string(5, RESULT_Y, LCD_W-10, 16, 16,
                    "Detecting...", YELLOW);
    LED0(0);

    /* Step1: ���ƶ�λ */
    plate_locate(g_frame, IMG_W, IMG_H, &g_plate_rect);
    if (!g_plate_rect.valid)
    {
        printf("[PLATE] locate failed\r\n");
        g_result_valid = 0;
        show_result();
        LED0(1);
        return;
    }
    printf("[PLATE] rect(%d,%d,%d,%d)\r\n",
           g_plate_rect.x, g_plate_rect.y,
           g_plate_rect.w, g_plate_rect.h);

    draw_rect(g_plate_rect.x, g_plate_rect.y,
              g_plate_rect.w, g_plate_rect.h, GREEN);

    /* Step2: �ַ��ָ� */
    CharRect char_rects[7];
    uint8_t  char_count = 0;
    plate_split_chars(g_frame, IMG_W, &g_plate_rect,
                      char_rects, &char_count);
    printf("[PLATE] chars=%d\r\n", char_count);

    if (char_count < 2)
    {
        g_result_valid = 0;
        show_result();
        LED0(1);
        return;
    }

    /* Step3: ���� */
    float (*nn_in)[800] = (float (*)[800])NN_INPUT_ADDR;
    uint8_t n = (char_count > 7) ? 7 : char_count;

    for (uint8_t i = 0; i < n; i++)
        plate_char_to_input(g_frame, IMG_W, &char_rects[i], nn_in[i]);

    g_plate_result.char_count   = n;
    g_plate_result.plate_str[0] = '\0';

    for (uint8_t i = 0; i < n; i++)
    {
        plate_infer_char(nn_in[i], &g_plate_result.chars[i]);
        strncat(g_plate_result.plate_str,
                g_plate_result.chars[i].char_utf8,
                sizeof(g_plate_result.plate_str)
                - strlen(g_plate_result.plate_str) - 1);
    }

    g_result_valid = 1;
    show_result();
    LED0(1);
}

/*==================== ����� ====================*/

void plate_recognition_test(void)
{
    lcd_clear(BLACK);
    lcd_show_string(5, 10, 230, 16, 16, "Plate Recognition", WHITE);
    lcd_show_string(5, 30, 230, 16, 16, "Initializing...",   GRAY);

    while (ov5640_init())
    {
        lcd_show_string(5, 50, 230, 16, 16, "OV5640 Error!", RED);
        printf("OV5640 init failed\r\n");
        delay_ms(500);
        lcd_fill(5, 50, 234, 70, BLACK);
        delay_ms(500);
        LED0_TOGGLE();
    }
    lcd_show_string(5, 50, 230, 16, 16, "OV5640 OK!", GREEN);
    printf("OV5640 OK\r\n");

    ov5640_rgb565_mode();
    ov5640_focus_init();
    ov5640_light_mode(0);
    ov5640_color_saturation(3);
    ov5640_brightness(4);
    ov5640_contrast(3);
    ov5640_sharpness(33);
    ov5640_focus_constant();

    /*
     * ���240��80�����߱�3:1���복��һ��
     * ������1280��800�����вü�
     * xƫ��=(1280-240)/2=520
     * yƫ��=(800-80)/2=360
     */
    ov5640_outsize_set(520, 360, IMG_W, IMG_H);

    dcmi_init();
    dcmi_dma_init((uint32_t)g_frame, 0,
                  (uint32_t)IMG_W * IMG_H / 2,
                  2, 1);
    dcmi_start();

    delay_ms(800);
    lcd_clear(BLACK);

    /* �ָ��� */
    lcd_fill(0, PREVIEW_H, LCD_W-1, PREVIEW_H+2, DARKBLUE);

    show_hint();
    g_state = STATE_PREVIEW;

    while (1)
    {
        uint8_t key = key_scan(0);

        switch (g_state)
        {
            case STATE_PREVIEW:
                dcmi_stop();
                flush_preview();
                dcmi_start();

                if (key == KEY0_PRES)
                {
                    dcmi_stop();
                    delay_ms(20);
                    flush_preview();
                    lcd_fill(0, PREVIEW_H, LCD_W-1, PREVIEW_H+2, YELLOW);
                    g_state = STATE_CAPTURE;
                }
                break;

            case STATE_CAPTURE:
                do_recognize();
                g_state = STATE_RESULT;
                break;

            case STATE_RESULT:
                if (key == KEY0_PRES)
                {
                    dcmi_start();
                    delay_ms(300);
                    dcmi_stop();
                    flush_preview();
                    lcd_fill(0, PREVIEW_H, LCD_W-1, PREVIEW_H+2, YELLOW);
                    do_recognize();
                    g_state = STATE_RESULT;
                }
                else if (key == KEY1_PRES)
                {
                    g_result_valid = 0;
                    lcd_fill(0, PREVIEW_H, LCD_W-1, PREVIEW_H+2, DARKBLUE);
                    show_hint();
                    dcmi_start();
                    g_state = STATE_PREVIEW;
                }
                break;
        }

        delay_ms(20);
    }
}