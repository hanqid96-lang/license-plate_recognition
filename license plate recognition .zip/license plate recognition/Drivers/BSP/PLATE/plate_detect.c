/**
 * @file    plate_detect.c
 * @brief   ���ƶ�λ + �ַ��ָ�
 *
 * �޸�˵��:
 *   1. Ԥ����������ѵ��һ��: ��ɫ�ַ�=1, ��ɫ����=0
 *   2. ����240��80��ͼ��ߴ磨���߱�3:1���복��һ�£�
 *   3. Otsu��ֵ��Python cv2.THRESH_OTSUһ��
 */

#include "plate_detect.h"
#include <string.h>

/*===================== ���ߺ��� =====================*/

static inline uint8_t rgb565_to_gray(uint16_t pixel)
{
    uint8_t r = ((pixel >> 11) & 0x1F) << 3;
    uint8_t g = ((pixel >> 5)  & 0x3F) << 2;
    uint8_t b = ( pixel        & 0x1F) << 3;
    return (uint8_t)((77 * r + 150 * g + 29 * b) >> 8);
}

/**
 * @brief  Otsu����Ӧ��ֵ����Python cv2.THRESH_OTSUһ�£�
 */
static uint8_t calc_otsu_thresh(const uint16_t *frame,
                                uint16_t img_w,
                                uint16_t x0, uint16_t y0,
                                uint16_t w,  uint16_t h)
{
    uint32_t hist[256] = {0};
    uint32_t total = (uint32_t)w * h;
    uint32_t sum_all = 0;
    uint32_t sumB = 0, wB = 0, wF;
    float    max_var = 0.0f;
    uint8_t  best_t = 128;
    uint16_t r, c, t;

    for (r = 0; r < h; r++)
        for (c = 0; c < w; c++)
        {
            uint32_t idx = (uint32_t)(y0 + r) * img_w + (x0 + c);
            hist[rgb565_to_gray(frame[idx])]++;
        }

    for (t = 0; t < 256; t++)
        sum_all += (uint32_t)t * hist[t];

    for (t = 0; t < 256; t++)
    {
        wB += hist[t];
        if (wB == 0) continue;
        wF = total - wB;
        if (wF == 0) break;

        sumB += (uint32_t)t * hist[t];
        float mB   = (float)sumB / (float)wB;
        float mF   = (float)(sum_all - sumB) / (float)wF;
        float diff = mB - mF;
        float var  = (float)wB * (float)wF * diff * diff;

        if (var > max_var)
        {
            max_var = var;
            best_t  = (uint8_t)t;
        }
    }
    return best_t;
}

/*===================== ���ƶ�λ =====================*/

void plate_locate(const uint16_t *frame,
                  uint16_t img_w, uint16_t img_h,
                  PlateRect *plate)
{
    plate->valid = 0;

    /*
     * ͼ����240��80������ռ�󲿷ֻ���
     * ֱ����ˮƽ��Եǿ�����ַ��ܼ�����
     */
    uint16_t best_start = 0, best_h = 0;
    uint32_t best_score = 0;

    for (uint16_t start = 0; start + 10 < img_h; start += 1)
    {
        for (uint16_t h = 10; h <= img_h - start; h += 2)
        {
            uint32_t score = 0;
            for (uint16_t y = start; y < start + h; y++)
            {
                for (uint16_t x = 1; x < img_w - 1; x++)
                {
                    uint8_t g0 = rgb565_to_gray(
                        frame[(uint32_t)y * img_w + x - 1]);
                    uint8_t g1 = rgb565_to_gray(
                        frame[(uint32_t)y * img_w + x + 1]);
                    int16_t diff = (int16_t)g0 - g1;
                    if (diff < 0) diff = -diff;
                    if (diff > 20) score++;
                }
            }
            if (score > best_score)
            {
                best_score = score;
                best_start = start;
                best_h     = h;
            }
        }
    }

    if (best_score < 100) return;

    /* �����ұ߽� */
    uint16_t col_score[240] = {0};
    for (uint16_t y = best_start; y < best_start + best_h; y++)
    {
        for (uint16_t x = 1; x < img_w - 1; x++)
        {
            uint8_t g0 = rgb565_to_gray(
                frame[(uint32_t)y * img_w + x - 1]);
            uint8_t g1 = rgb565_to_gray(
                frame[(uint32_t)y * img_w + x + 1]);
            int16_t diff = (int16_t)g0 - g1;
            if (diff < 0) diff = -diff;
            if (diff > 20) col_score[x]++;
        }
    }

    uint16_t left = img_w, right = 0;
    for (uint16_t x = 0; x < img_w; x++)
    {
        if (col_score[x] > 1)
        {
            if (x < left)  left  = x;
            if (x > right) right = x;
        }
    }

    if (right <= left + 20) return;

    plate->x = (left  > 2) ? left  - 2 : 0;
    plate->y = (best_start > 1) ? best_start - 1 : 0;
    plate->w = right - left + 4;
    plate->h = best_h + 2;
    plate->valid = 1;
}

/*===================== �ַ��ָ� =====================*/

static uint8_t s_bin_buf[80 * 240];

void plate_split_chars(const uint16_t *frame,
                       uint16_t img_w,
                       const PlateRect *plate,
                       CharRect chars[7],
                       uint8_t *char_count)
{
    uint16_t pw, ph;
    uint8_t  thresh;
    uint16_t r, c;
    uint32_t idx;
    uint8_t  gray;
    uint8_t  col_proj[240] = {0};
    uint16_t cnt_col;
    uint8_t  in_char = 0;
    uint16_t char_start = 0;
    uint8_t  cnt = 0;
    uint16_t min_cw, max_cw, cw;
    uint8_t  val;

    *char_count = 0;
    if (!plate->valid) return;

    pw = plate->w;
    ph = plate->h;
    if (pw > 240) pw = 240;
    if (ph > 80)  ph = 80;

    /* Otsu��ֵ */
    thresh = calc_otsu_thresh(frame, img_w,
                              plate->x, plate->y,
                              pw, ph);

    /*
     * ��ֵ������ѵ��һ��
     * ѵ��ʱ: cv2.THRESH_BINARY + THRESH_OTSU
     * gray < thresh -> ��ɫ�ַ� -> 1
     * gray >= thresh -> ��ɫ���� -> 0
     */
    for (r = 0; r < ph; r++)
    {
        for (c = 0; c < pw; c++)
        {
            idx  = (uint32_t)(plate->y + r) * img_w + (plate->x + c);
            gray = rgb565_to_gray(frame[idx]);
            s_bin_buf[r * pw + c] = (gray < thresh) ? 1 : 0;
        }
    }

    /* ��ͶӰ */
    for (c = 0; c < pw; c++)
    {
        cnt_col = 0;
        for (r = 0; r < ph; r++)
            cnt_col += s_bin_buf[r * pw + c];
        col_proj[c] = (cnt_col > ph / 6) ? 1 : 0;
    }

    /* ��ȡ�ַ����� */
    min_cw = pw / 20;
    max_cw = pw / 4;
    if (min_cw < 2) min_cw = 2;

    for (c = 0; c <= pw && cnt < 7; c++)
    {
        val = (c < pw) ? col_proj[c] : 0;
        if (!in_char && val)
        {
            in_char    = 1;
            char_start = c;
        }
        else if (in_char && !val)
        {
            in_char = 0;
            cw = c - char_start;
            if (cw >= min_cw && cw <= max_cw)
            {
                chars[cnt].x = plate->x + char_start;
                chars[cnt].y = plate->y;
                chars[cnt].w = cw;
                chars[cnt].h = ph;
                cnt++;
            }
        }
    }
    *char_count = cnt;
}

/*===================== �ַ�Ԥ����ΪNN���� =====================*/

void plate_char_to_input(const uint16_t *frame,
                         uint16_t img_w,
                         const CharRect *cr,
                         float out_800[800])
{
    const uint16_t OUT_H = 40;
    const uint16_t OUT_W = 20;
    uint16_t oy, ox, sy, sx;
    uint32_t idx;
    uint8_t  gray, thresh;

    thresh = calc_otsu_thresh(frame, img_w,
                              cr->x, cr->y,
                              cr->w, cr->h);

    for (oy = 0; oy < OUT_H; oy++)
    {
        for (ox = 0; ox < OUT_W; ox++)
        {
            sy = (uint16_t)((uint32_t)oy * cr->h / OUT_H);
            sx = (uint16_t)((uint32_t)ox * cr->w / OUT_W);
            if (sy >= cr->h) sy = cr->h - 1;
            if (sx >= cr->w) sx = cr->w - 1;

            idx  = (uint32_t)(cr->y + sy) * img_w + (cr->x + sx);
            gray = rgb565_to_gray(frame[idx]);

            /*
             * ��ѵ��һ�£���ɫ�ַ�=1����ɫ����=0
             * cv2.THRESH_BINARY: gray < thresh -> 1
             */
            out_800[oy * OUT_W + ox] = (gray < thresh) ? 1.0f : 0.0f;
        }
    }
}