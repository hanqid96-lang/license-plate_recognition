#ifndef __TOUCH_H
#define __TOUCH_H

#include "./SYSTEM/sys/sys.h"

/* ���ٰ���������ͷ�ļ� */


/******************************************************************************************/
/* ���败��������IC ���Ŷ��� */

#define T_PEN_GPIO_PORT                 GPIOH
#define T_PEN_GPIO_PIN                  SYS_GPIO_PIN7
#define T_PEN_GPIO_CLK_ENABLE()         do{ RCC->AHB1ENR |= 1 << 7; }while(0)

#define T_CS_GPIO_PORT                  GPIOI
#define T_CS_GPIO_PIN                   SYS_GPIO_PIN8
#define T_CS_GPIO_CLK_ENABLE()          do{ RCC->AHB1ENR |= 1 << 8; }while(0)

#define T_MISO_GPIO_PORT                GPIOG
#define T_MISO_GPIO_PIN                 SYS_GPIO_PIN3
#define T_MISO_GPIO_CLK_ENABLE()        do{ RCC->AHB1ENR |= 1 << 6; }while(0)

#define T_MOSI_GPIO_PORT                GPIOI
#define T_MOSI_GPIO_PIN                 SYS_GPIO_PIN3
#define T_MOSI_GPIO_CLK_ENABLE()        do{ RCC->AHB1ENR |= 1 << 8; }while(0)

#define T_CLK_GPIO_PORT                 GPIOH
#define T_CLK_GPIO_PIN                  SYS_GPIO_PIN6
#define T_CLK_GPIO_CLK_ENABLE()         do{ RCC->AHB1ENR |= 1 << 7; }while(0)

/******************************************************************************************/
/* ���败������������ */

#define T_PEN           sys_gpio_pin_get(T_PEN_GPIO_PORT, T_PEN_GPIO_PIN)
#define T_MISO          sys_gpio_pin_get(T_MISO_GPIO_PORT, T_MISO_GPIO_PIN)

#define T_MOSI(x)       sys_gpio_pin_set(T_MOSI_GPIO_PORT, T_MOSI_GPIO_PIN, x)
#define T_CLK(x)        sys_gpio_pin_set(T_CLK_GPIO_PORT, T_CLK_GPIO_PIN, x)
#define T_CS(x)         sys_gpio_pin_set(T_CS_GPIO_PORT, T_CS_GPIO_PIN, x)

/******************************************************************************************/

#define TP_PRES_DOWN    0x8000
#define TP_CATH_PRES    0x4000
#define CT_MAX_TOUCH    10

/* ������������ */
typedef struct
{
    uint8_t (*init)(void);
    uint8_t (*scan)(uint8_t);
    void (*adjust)(void);
    uint16_t x[CT_MAX_TOUCH];
    uint16_t y[CT_MAX_TOUCH];
    uint16_t sta;
    float xfac;
    float yfac;
    short xc;
    short yc;
    uint8_t touchtype;
} _m_tp_dev;

extern _m_tp_dev tp_dev;

/* �������� */
uint8_t tp_init(void);
uint8_t tp_scan(uint8_t mode);
void tp_adjust(void);
void tp_save_adjust_data(void);
uint8_t tp_get_adjust_data(void);
void tp_draw_big_point(uint16_t x, uint16_t y, uint16_t color);

#endif
