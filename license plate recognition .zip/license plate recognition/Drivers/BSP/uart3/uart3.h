#ifndef __UART3_H
#define __UART3_H

#include "./SYSTEM/sys/sys.h"
#include <string.h>

#define WIFI_RX_BUF_SIZE    512

extern uint8_t  wifi_rx_buf[WIFI_RX_BUF_SIZE];
extern volatile uint16_t wifi_rx_len;
extern volatile uint8_t  wifi_rx_done;

void    uart3_init(uint32_t pclk1, uint32_t baudrate);
void    uart3_send_byte(uint8_t data);
void    uart3_send_string(char *str);
void    uart3_send_chars(uint8_t *data, uint16_t len);
void    uart3_clear_buf(void);

#endif
