#ifndef _OV5640_H
#define _OV5640_H

#include "./SYSTEM/sys/sys.h"
#include "./BSP/OV5640/sccb.h"

/******************************************************************************************/
/* RESET����: PA15 */
#define OV_RESET_GPIO_PORT              GPIOA
#define OV_RESET_GPIO_PIN               SYS_GPIO_PIN15
#define OV_RESET_GPIO_CLK_ENABLE()      do{ RCC->AHB1ENR |= 1 << 0; }while(0)

/* �� PWDN����: PG9����İ���ֱ��GPIO������PCF8574���� */
#define OV_PWDN_GPIO_PORT               GPIOG
#define OV_PWDN_GPIO_PIN                SYS_GPIO_PIN9
#define OV_PWDN_GPIO_CLK_ENABLE()       do{ RCC->AHB1ENR |= 1 << 6; }while(0)

/******************************************************************************************/

#define OV5640_RST(x)       sys_gpio_pin_set(OV_RESET_GPIO_PORT, OV_RESET_GPIO_PIN, x)
#define OV5640_PWDN(x)      sys_gpio_pin_set(OV_PWDN_GPIO_PORT, OV_PWDN_GPIO_PIN, x)

#define OV5640_ID           0X5640
#define OV5640_ADDR         0X78

#define OV5640_CHIPIDH      0X300A
#define OV5640_CHIPIDL      0X300B

uint8_t ov5640_read_reg(uint16_t reg);
uint8_t ov5640_write_reg(uint16_t reg, uint8_t data);
void    ov5640_pwdn_set(uint8_t sta);

uint8_t ov5640_init(void);
void    ov5640_jpeg_mode(void);
void    ov5640_rgb565_mode(void);

uint8_t ov5640_focus_init(void);
uint8_t ov5640_focus_single(void);
uint8_t ov5640_focus_constant(void);

void    ov5640_flash_ctrl(uint8_t sw);
void    ov5640_test_pattern(uint8_t mode);
void    ov5640_sharpness(uint8_t sharp);
void    ov5640_brightness(uint8_t bright);
void    ov5640_contrast(uint8_t contrast);
void    ov5640_exposure(uint8_t exposure);
void    ov5640_light_mode(uint8_t mode);
void    ov5640_special_effects(uint8_t eft);
void    ov5640_color_saturation(uint8_t sat);

uint8_t ov5640_outsize_set(uint16_t offx, uint16_t offy, uint16_t width, uint16_t height);
uint8_t ov5640_image_window_set(uint16_t offx, uint16_t offy, uint16_t width, uint16_t height);

#endif
