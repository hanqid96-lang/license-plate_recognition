/**
 * @brief  OV5640����ͷ���� �� ��������ԭ�ӣ�������İ���
 *         PWDN=PG9, XCLK=PA8(MCO1), ����DCMI���Ų���
 *
 * �� ע�⣺DCMI��PC6/PC7/PC8/PC9/PC11��TF������IO
 *         ��������ͷʱ����ͬʱʹ��TF����
 *
 * �� ע�⣺���WiFi��PC10/PC11(USART3)��PC11��DCMI_D4��ͻ
 *         ����ͷ��WiFi����ͬʱʹ�ã�
 */

#include "./BSP/CAMERA/camera.h"
#include "./SYSTEM/usart/usart.h"
#include "./SYSTEM/delay/delay.h"
#include "./BSP/LED/led.h"
#include "./BSP/LCD/lcd.h"

#include "./BSP/KEY/key.h"
#include "./BSP/SDRAM/sdram.h"
#include "./BSP/DCMI/dcmi.h"
#include "./BSP/OV5640/ov5640.h"
#include <stdio.h>
#include <string.h>
/* ---- ���ݣ�����Ŀʹ��RGB��(LTDC)��pwidth��0 ---- */
/* ������õ���MCU��(8080�ӿ�)���������Ϊ #define IS_RGB_LCD  0 */
#define IS_RGB_LCD  1
extern void ltdc_color_fill(uint16_t sx, uint16_t sy, uint16_t ex, uint16_t ey, uint16_t *color);
/*======================== ȫ�ֱ��� ========================*/

uint8_t  g_ov_mode  = 0;       /* 0:RGB565  1:JPEG */
uint8_t  g_ov_frame = 0;       /* ֡�ʼ���(���ⲿ��ʱ��ͳ��) */
uint16_t g_curline  = 0;       /* ��ǰ�б�� */
uint16_t g_yoffset  = 0;       /* Y����ƫ�� */

#define JPEG_LINE_SIZE      (4 * 1024)
#define JPEG_BUF_SIZE       (1 * 1024 * 1024)

/* �л��棨˫���壩 */
uint32_t g_dcmi_line_buf[2][JPEG_LINE_SIZE];

/* JPEG���ݻ��棨����SDRAM�� */
#if !(__ARMCC_VERSION >= 6010050)
uint32_t g_jpeg_data_buf[JPEG_BUF_SIZE] __attribute__((at(0XC0000000 + 1280 * 800 * 2)));
#else
uint32_t g_jpeg_data_buf[JPEG_BUF_SIZE] __attribute__((section(".bss.ARM.__at_0XC01F4000")));
#endif

volatile uint32_t g_jpeg_data_len = 0;
volatile uint8_t  g_jpeg_data_ok  = 0;

/* ��Ч���� */
const char *CAMERA_EFFECTS_TBL[7] = {
    "Normal", "Cool", "Warm", "B&W", "Yellowish", "Inverse", "Greenish"
};

/*======================== DCMI/DMA�ص� ========================*/

/**
 * @brief  JPEG֡���ݴ�����DCMI֡�жϵ��ã�
 */
void jpeg_data_process(void)
{
    uint16_t i;
    uint16_t rlen;
    uint32_t *pbuf;

    g_curline = g_yoffset;

    if (g_ov_mode & 0X01)   /* JPEGģʽ */
    {
        if (g_jpeg_data_ok == 0)
        {
            DMA2_Stream1->CR &= ~(1 << 0);
            while (DMA2_Stream1->CR & 0X01);

            rlen = JPEG_LINE_SIZE - DMA2_Stream1->NDTR;
            pbuf = g_jpeg_data_buf + g_jpeg_data_len;

            if (DMA2_Stream1->CR & (1 << 19))
            {
                for (i = 0; i < rlen; i++) pbuf[i] = g_dcmi_line_buf[1][i];
            }
            else
            {
                for (i = 0; i < rlen; i++) pbuf[i] = g_dcmi_line_buf[0][i];
            }

            g_jpeg_data_len += rlen;
            g_jpeg_data_ok = 1;
        }

        if (g_jpeg_data_ok == 2)
        {
            DMA2_Stream1->NDTR = JPEG_LINE_SIZE;
            DMA2_Stream1->CR |= 1 << 0;
            g_jpeg_data_ok = 0;
            g_jpeg_data_len = 0;
        }
    }
    else    /* RGB565ģʽ */
    {
        if (!IS_RGB_LCD)    /* MCU�� */
        {
            lcd_set_cursor(0, 0);
            lcd_write_ram_prepare();
        }
    }
}

/**
 * @brief  JPEGģʽDMA˫����ص�
 */
void jpeg_dcmi_rx_callback(void)
{
    uint16_t i;
    uint32_t *pbuf;
    pbuf = g_jpeg_data_buf + g_jpeg_data_len;

    if (DMA2_Stream1->CR & (1 << 19))
    {
        for (i = 0; i < JPEG_LINE_SIZE; i++) pbuf[i] = g_dcmi_line_buf[0][i];
    }
    else
    {
        for (i = 0; i < JPEG_LINE_SIZE; i++) pbuf[i] = g_dcmi_line_buf[1][i];
    }

    g_jpeg_data_len += JPEG_LINE_SIZE;
}

/**
 * @brief  RGB��DMA˫����ص���������䣩
 */
void rgblcd_dcmi_rx_callback(void)
{
    uint16_t *pbuf;

    if (DMA2_Stream1->CR & (1 << 19))
        pbuf = (uint16_t *)g_dcmi_line_buf[0];
    else
        pbuf = (uint16_t *)g_dcmi_line_buf[1];

    lcd_color_fill(0, g_curline, lcddev.width - 1, g_curline, pbuf);

    if (g_curline < lcddev.height) g_curline++;
}

/*======================== RGB565���� ========================*/

/**
 * @brief  RGB565����ͷ����
 *         KEY0: �Աȶ�
 *         KEY1: �Զ��Խ�
 *         KEY2: ��Ч
 *
 * �� �����İ���������ͬ�����滻 KEY0_PRES/KEY1_PRES/KEY2_PRES ��
 */
void camera_rgb565_test(void)
{
    uint8_t key;
    uint8_t effect = 0, contrast = 2;
    uint8_t scale = 1;
    char msgbuf[30];
    uint16_t outputheight = 0;
    float fac = 0;

    lcd_clear(WHITE);
    lcd_show_string(30, 50,  200, 16, 16, "OV5640 RGB565 Mode", RED);
    lcd_show_string(30, 80,  200, 16, 16, "KEY0:Contrast", RED);
    lcd_show_string(30, 100, 200, 16, 16, "KEY1:AUTO Focus", RED);
    lcd_show_string(30, 120, 200, 16, 16, "KEY2:Effects", RED);

    /* ��ʼ��OV5640 */
    ov5640_rgb565_mode();
    ov5640_focus_init();
    ov5640_light_mode(0);
    ov5640_color_saturation(3);
    ov5640_brightness(4);
    ov5640_contrast(3);
    ov5640_sharpness(33);
    ov5640_focus_constant();

    /* DCMI��ʼ�� */
    dcmi_init();

    if (IS_RGB_LCD)    /* RGB�� */
    {
        dcmi_rx_callback = rgblcd_dcmi_rx_callback;
        dcmi_dma_init((uint32_t)g_dcmi_line_buf[0],
                      (uint32_t)g_dcmi_line_buf[1],
                      lcddev.width / 2, 1, 1);
    }
    else    /* MCU�� �� DMAֱдLCD */
    {
        dcmi_dma_init((uint32_t)&LCD->LCD_RAM, 0, 1, 1, 0);
    }

    /* ������Ļ�߶ȵ��� */
    if (lcddev.height > 800)
    {
        g_yoffset = (lcddev.height - 800) / 2;
        outputheight = 800;
        ov5640_write_reg(0x3035, 0X51);
    }
    else
    {
        g_yoffset = 0;
        outputheight = lcddev.height;
    }

    g_curline = g_yoffset;
    ov5640_outsize_set(202, 0, lcddev.width, outputheight);
    dcmi_start();
    lcd_clear(0xFFFF);

    while (1)
    {
        key = key_scan(0);

        if (key)
        {
            if (key != KEY1_PRES) dcmi_stop();

            switch (key)
            {
                case KEY0_PRES:
                    contrast++;
                    if (contrast > 6) contrast = 0;
                    ov5640_contrast(contrast);
                    sprintf(msgbuf, "Contrast:%d", (signed char)contrast - 3);
                    break;

                case KEY1_PRES:
                    ov5640_focus_single();
                    break;

                case KEY2_PRES:
                    effect++;
                    if (effect > 6) effect = 0;
                    ov5640_special_effects(effect);
                    sprintf(msgbuf, "%s", CAMERA_EFFECTS_TBL[effect]);
                    break;

                case WKUP_PRES:
                    scale = !scale;
                    if (scale == 0)
                    {
                        fac = (float)800 / outputheight;
                        ov5640_outsize_set((1280 - fac * lcddev.width) / 2,
                                           (800 - fac * outputheight) / 2,
                                           lcddev.width, outputheight);
                        sprintf(msgbuf, "Full Size 1:1");
                    }
                    else
                    {
                        ov5640_outsize_set(202, 0, lcddev.width, outputheight);
                        sprintf(msgbuf, "Scale");
                    }
                    break;
            }

            if (key != KEY1_PRES)
            {
                lcd_show_string(30, 50, 210, 16, 16, msgbuf, RED);
                delay_ms(800);
                dcmi_start();
            }
        }

        delay_ms(10);
    }
}

/*======================== ����ͷ������� ========================*/

/**
 * @brief  ����ͷ����������
 */
void camera_test(void)
{
    lcd_clear(WHITE);
    lcd_show_string(30, 50, 200, 16, 16, "OV5640 Camera Test", RED);
    lcd_show_string(30, 80, 200, 16, 16, "Initializing...", BLUE);

    /* ��ʼ��OV5640 */
    while (ov5640_init())
    {
        lcd_show_string(30, 110, 240, 16, 16, "OV5640 ERROR!", RED);
        printf("OV5640 init failed!\r\n");
        delay_ms(500);
        lcd_fill(30, 110, 239, 130, WHITE);
        delay_ms(500);
        LED0_TOGGLE();
    }

    lcd_show_string(30, 110, 200, 16, 16, "OV5640 OK!", GREEN);
    printf("OV5640 init OK!\r\n");
    delay_ms(1000);

    /* ֱ�ӽ���RGB565���� */
    g_ov_mode = 0;
    camera_rgb565_test();
}
