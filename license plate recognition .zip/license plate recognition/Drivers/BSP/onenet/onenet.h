#ifndef __ONENET_H
#define __ONENET_H

#include "./SYSTEM/sys/sys.h"
#include "./BSP/WIFI/wifi.h"
#include <stdio.h>
#include <string.h>

/* OneNET MQTT������ */
#define MQTT_SERVER     "mqtts.heclouds.com"
#define MQTT_PORT       "1883"

/* MQTT��¼��Ϣ */
#define MQTT_CLIENT_ID  "device01"
#define MQTT_USERNAME   "6llKGS5po8"
#define MQTT_PASSWORD   "version=2018-10-31&res=products%2F6llKGS5po8%2Fdevices%2Fdevice01&et=2735660800&method=sha256&sign=DTuFduK3BwPavLv7%2FSwc86q1WzSwf5iKhJ%2FzVZ3DmGA%3D"

/* �����ϱ�Topic */
#define MQTT_TOPIC_POST "$sys/6llKGS5po8/device01/thing/property/post"

uint8_t onenet_connect_tcp(void);
uint8_t onenet_mqtt_login(void);
uint8_t onenet_send_data(float temperature, float humidity);
uint8_t onenet_send_adc(float voltage);

#endif
