#include "./BSP/ONENET/onenet.h"
#include "./SYSTEM/delay/delay.h"

static uint8_t  mqtt_buf[500];
static uint16_t mqtt_len;

/**
 * @brief  д��MQTTʣ�೤�ȣ��䳤���룩
 */
static uint16_t mqtt_write_remain_len(uint8_t *buf, uint16_t len)
{
    uint16_t i = 0;
    do {
        buf[i] = len % 128;
        len = len / 128;
        if (len > 0)
            buf[i] |= 0x80;
        i++;
    } while (len > 0);
    return i;
}

/**
 * @brief  д��MQTT UTF-8�ַ���
 */
static uint16_t mqtt_write_string(uint8_t *buf, const char *str)
{
    uint16_t len = strlen(str);
    buf[0] = (len >> 8) & 0xFF;
    buf[1] = len & 0xFF;
    memcpy(&buf[2], str, len);
    return 2 + len;
}

/**
 * @brief  ͨ��AT+CIPSEND���Ͷ���������
 */
static uint8_t mqtt_send_raw(uint8_t *data, uint16_t len)
{
    char cmd[25];
    uint16_t timeout;

    sprintf(cmd, "AT+CIPSEND=%d\r\n", len);
    wifi_clear_buf();
    uart3_send_string(cmd);

    /* �ȴ� > */
    timeout = 5000;
    while (timeout--)
    {
        delay_ms(1);
        if (strstr((char *)wifi_rx_buf, ">") != NULL)
            break;
    }
    if (timeout == 0) return 0;

    /* �������� */
    wifi_clear_buf();
    uart3_send_chars(data, len);

    /* �ȴ�SEND OK */
    timeout = 5000;
    while (timeout--)
    {
        delay_ms(1);
        if (wifi_rx_done)
        {
            wifi_rx_done = 0;
            if (strstr((char *)wifi_rx_buf, "SEND OK") != NULL)
                return 1;
        }
        if (wifi_rx_len > 0 && strstr((char *)wifi_rx_buf, "SEND OK") != NULL)
            return 1;
    }
    return 0;
}

/**
 * @brief  ����OneNET TCP������
 */
uint8_t onenet_connect_tcp(void)
{
    uint8_t result;
    char cmd[80];

    wifi_send_at("AT+CIPMUX=0\r\n", "OK", 2000);
    delay_ms(500);

    sprintf(cmd, "AT+CIPSTART=\"TCP\",\"%s\",%s\r\n", MQTT_SERVER, MQTT_PORT);
    result = wifi_send_at(cmd, "CONNECT", 10000);

    if (!result)
    {
        if (strstr((char *)wifi_rx_buf, "ALREADY") != NULL)
            result = 1;
    }

    return result;
}

/**
 * @brief  MQTT CONNECT���� �� ��¼OneNET
 */
uint8_t onenet_mqtt_login(void)
{
    uint16_t i = 0;
    uint16_t remain_len;
    uint8_t  tmp_buf[4];
    uint16_t rl_bytes;

    /* ����ʣ�೤�� */
    remain_len = 10
               + 2 + strlen(MQTT_CLIENT_ID)
               + 2 + strlen(MQTT_USERNAME)
               + 2 + strlen(MQTT_PASSWORD);

    /* �̶���ͷ */
    mqtt_buf[i++] = 0x10;

    /* ʣ�೤�� */
    rl_bytes = mqtt_write_remain_len(tmp_buf, remain_len);
    memcpy(&mqtt_buf[i], tmp_buf, rl_bytes);
    i += rl_bytes;

    /* Э���� MQTT */
    mqtt_buf[i++] = 0x00;
    mqtt_buf[i++] = 0x04;
    mqtt_buf[i++] = 'M';
    mqtt_buf[i++] = 'Q';
    mqtt_buf[i++] = 'T';
    mqtt_buf[i++] = 'T';

    /* Э�鼶�� */
    mqtt_buf[i++] = 0x04;

    /* ���ӱ�־ */
    mqtt_buf[i++] = 0xC2;

    /* ����ʱ�� 120�� */
    mqtt_buf[i++] = 0x00;
    mqtt_buf[i++] = 0x78;

    /* �غ� */
    i += mqtt_write_string(&mqtt_buf[i], MQTT_CLIENT_ID);
    i += mqtt_write_string(&mqtt_buf[i], MQTT_USERNAME);
    i += mqtt_write_string(&mqtt_buf[i], MQTT_PASSWORD);

    mqtt_len = i;

    if (!mqtt_send_raw(mqtt_buf, mqtt_len))
        return 0;

    /* �ȴ�CONNACK */
    delay_ms(2000);

    if (strstr((char *)wifi_rx_buf, "+IPD") != NULL)
        return 1;

    delay_ms(2000);
    if (wifi_rx_len > 0)
        return 1;

    return 0;
}

/**
 * @brief  �ϱ���ʪ�ȵ�OneNET
 */
uint8_t onenet_send_data(float temperature, float humidity)
{
    char json[200];
    uint16_t json_len;
    uint16_t topic_len;
    uint16_t remain_len;
    uint16_t i = 0;
    uint8_t  tmp_buf[4];
    uint16_t rl_bytes;

    sprintf(json,
        "{\"id\":\"123\","
        "\"params\":{"
        "\"temperature\":{\"value\":%.1f},"
        "\"humidity\":{\"value\":%.1f}"
        "}}",
        temperature, humidity);

    json_len  = strlen(json);
    topic_len = strlen(MQTT_TOPIC_POST);
    remain_len = 2 + topic_len + json_len;

    mqtt_buf[i++] = 0x30;

    rl_bytes = mqtt_write_remain_len(tmp_buf, remain_len);
    memcpy(&mqtt_buf[i], tmp_buf, rl_bytes);
    i += rl_bytes;

    i += mqtt_write_string(&mqtt_buf[i], MQTT_TOPIC_POST);

    memcpy(&mqtt_buf[i], json, json_len);
    i += json_len;

    mqtt_len = i;
    return mqtt_send_raw(mqtt_buf, mqtt_len);
}

/**
 * @brief  �ϱ�ADC��ѹ��OneNET
 */
uint8_t onenet_send_adc(float voltage)
{
    char json[150];
    uint16_t json_len;
    uint16_t topic_len;
    uint16_t remain_len;
    uint16_t i = 0;
    uint8_t  tmp_buf[4];
    uint16_t rl_bytes;

    sprintf(json,
        "{\"id\":\"123\","
        "\"params\":{"
        "\"voltage\":{\"value\":%.3f}"
        "}}", voltage);

    json_len  = strlen(json);
    topic_len = strlen(MQTT_TOPIC_POST);
    remain_len = 2 + topic_len + json_len;

    mqtt_buf[i++] = 0x30;

    rl_bytes = mqtt_write_remain_len(tmp_buf, remain_len);
    memcpy(&mqtt_buf[i], tmp_buf, rl_bytes);
    i += rl_bytes;

    i += mqtt_write_string(&mqtt_buf[i], MQTT_TOPIC_POST);

    memcpy(&mqtt_buf[i], json, json_len);
    i += json_len;

    mqtt_len = i;
    return mqtt_send_raw(mqtt_buf, mqtt_len);
}
