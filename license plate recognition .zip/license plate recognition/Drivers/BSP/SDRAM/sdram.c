#include "./SYSTEM/delay/delay.h"
#include "./BSP/SDRAM/sdram.h"

uint8_t sdram_send_cmd(uint8_t bankx, uint8_t cmd, uint8_t refresh, uint16_t regval)
{
    uint32_t retry = 0;
    uint32_t tempreg = 0;

    tempreg |= cmd << 0;
    tempreg |= 1 << (4 - bankx);
    tempreg |= refresh << 5;
    tempreg |= regval << 9;
    FMC_Bank5_6->SDCMR = tempreg;

    while ((FMC_Bank5_6->SDSR & (1 << 5)))
    {
        retry++;
        if (retry > 0X1FFFFF) return 1;
    }

    return 0;
}

void sdram_init(void)
{
    uint32_t sdctrlreg = 0, sdtimereg = 0;
    uint16_t mregval = 0;

    RCC->AHB1ENR |= 0X1F << 2;
    RCC->AHB3ENR |= 1 << 0;

    sys_gpio_set(GPIOC, SYS_GPIO_PIN0 | SYS_GPIO_PIN2 | SYS_GPIO_PIN3,
                 SYS_GPIO_MODE_AF, SYS_GPIO_OTYPE_PP, SYS_GPIO_SPEED_HIGH, SYS_GPIO_PUPD_PU);

    sys_gpio_set(GPIOD, 3 << 0 | 7 << 8 | 3 << 14,
                 SYS_GPIO_MODE_AF, SYS_GPIO_OTYPE_PP, SYS_GPIO_SPEED_HIGH, SYS_GPIO_PUPD_PU);

    sys_gpio_set(GPIOE, 3 << 0 | 0X1FF << 7,
                 SYS_GPIO_MODE_AF, SYS_GPIO_OTYPE_PP, SYS_GPIO_SPEED_HIGH, SYS_GPIO_PUPD_PU);

    sys_gpio_set(GPIOF, 0X3F << 0 | 0X1F << 11,
                 SYS_GPIO_MODE_AF, SYS_GPIO_OTYPE_PP, SYS_GPIO_SPEED_HIGH, SYS_GPIO_PUPD_PU);

    sys_gpio_set(GPIOG, 7 << 0 | 3 << 4 | SYS_GPIO_PIN8 | SYS_GPIO_PIN15,
                 SYS_GPIO_MODE_AF, SYS_GPIO_OTYPE_PP, SYS_GPIO_SPEED_HIGH, SYS_GPIO_PUPD_PU);

    sys_gpio_af_set(GPIOC, SYS_GPIO_PIN0 | SYS_GPIO_PIN2 | SYS_GPIO_PIN3, 12);
    sys_gpio_af_set(GPIOD, 3 << 0 | 7 << 8 | 3 << 14, 12);
    sys_gpio_af_set(GPIOE, 3 << 0 | 0X1FF << 7, 12);
    sys_gpio_af_set(GPIOF, 0X3F << 0 | 0X1F << 11, 12);
    sys_gpio_af_set(GPIOG, 7 << 0 | 3 << 4 | SYS_GPIO_PIN8 | SYS_GPIO_PIN15, 12);

    sdctrlreg |= 1 << 0;
    sdctrlreg |= 2 << 2;
    sdctrlreg |= 1 << 4;
    sdctrlreg |= 1 << 6;
    sdctrlreg |= 2 << 7;
    sdctrlreg |= 0 << 9;
    sdctrlreg |= 2 << 10;
    sdctrlreg |= 1 << 12;
    sdctrlreg |= 0 << 13;
    FMC_Bank5_6->SDCR[0] = sdctrlreg;

    sdtimereg |= 1 << 0;
    sdtimereg |= 6 << 4;
    sdtimereg |= 5 << 8;
    sdtimereg |= 5 << 12;
    sdtimereg |= 1 << 16;
    sdtimereg |= 1 << 20;
    sdtimereg |= 1 << 24;
    FMC_Bank5_6->SDTR[0] = sdtimereg;

    sdram_send_cmd(0, 1, 0, 0);
    delay_us(500);
    sdram_send_cmd(0, 2, 0, 0);
    sdram_send_cmd(0, 3, 8, 0);

    mregval |= 1 << 0;
    mregval |= 0 << 3;
    mregval |= 2 << 4;
    mregval |= 0 << 7;
    mregval |= 1 << 9;
    sdram_send_cmd(0, 4, 0, mregval);

    FMC_Bank5_6->SDRTR = 730 << 1;
}

void fmc_sdram_write_buffer(uint8_t *pbuf, uint32_t addr, uint32_t n)
{
    for (; n != 0; n--)
    {
        *(volatile uint8_t *)(BANK5_SDRAM_ADDR + addr) = *pbuf;
        addr++;
        pbuf++;
    }
}

void fmc_sdram_read_buffer(uint8_t *pbuf, uint32_t addr, uint32_t n)
{
    for (; n != 0; n--)
    {
        *pbuf++ = *(volatile uint8_t *)(BANK5_SDRAM_ADDR + addr);
        addr++;
    }
}
