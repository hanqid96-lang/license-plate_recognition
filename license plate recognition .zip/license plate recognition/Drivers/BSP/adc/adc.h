#ifndef __ADC_H
#define __ADC_H

#include "./SYSTEM/sys/sys.h"

/*---------------------- ���Ŷ��� ----------------------*/
/* ADC1 - PA7  (ADC1_IN7) */
#define ADC1_GPIO_PORT      GPIOA
#define ADC1_GPIO_PIN       SYS_GPIO_PIN7
#define ADC1_GPIO_CLK_EN()  do{ RCC->AHB1ENR |= (1 << 0); }while(0)
#define ADC1_CHN            7       /* PA7 = ADC channel 7 */

/* ADC2 - PC4  (ADC1_IN14) */
#define ADC2_GPIO_PORT      GPIOC
#define ADC2_GPIO_PIN       SYS_GPIO_PIN4
#define ADC2_GPIO_CLK_EN()  do{ RCC->AHB1ENR |= (1 << 2); }while(0)
#define ADC2_CHN            14      /* PC4 = ADC channel 14 */

/* ADC3 - PC5  (ADC1_IN15) */
#define ADC3_GPIO_PORT      GPIOC
#define ADC3_GPIO_PIN       SYS_GPIO_PIN5
#define ADC3_GPIO_CLK_EN()  do{ RCC->AHB1ENR |= (1 << 2); }while(0)
#define ADC3_CHN            15      /* PC5 = ADC channel 15 */

/* ADC1����ʱ��ʹ�� */
#define ADC1_CLK_EN()       do{ RCC->APB2ENR |= (1 << 8); }while(0)

/*---------------------- �������� ----------------------*/
void     adc_init(void);
uint16_t adc_read_channel(uint8_t ch);              /* ��ȡָ��ͨ��ADCֵ, 0~4095 */
uint16_t adc_read_channel_average(uint8_t ch, uint8_t times);  /* ��β���ȡƽ�� */
uint16_t adc_read_voltage(uint8_t ch);              /* ��ȡ��ѹֵ(mV), 0~3300 */

#endif
