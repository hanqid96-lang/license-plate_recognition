..\..\output\plate_detect.o: ..\..\Drivers\BSP\PLATE\plate_detect.c
..\..\output\plate_detect.o: ..\..\Drivers\BSP\PLATE\plate_detect.h
..\..\output\plate_detect.o: D:\keil5\ARM\ARMCC\Bin\..\include\stdint.h
..\..\output\plate_detect.o: D:\keil5\ARM\ARMCC\Bin\..\include\string.h
