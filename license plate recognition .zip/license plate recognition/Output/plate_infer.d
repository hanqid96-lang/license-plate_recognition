..\..\output\plate_infer.o: ..\..\Drivers\BSP\PLATE\plate_infer.c
..\..\output\plate_infer.o: ..\..\Drivers\BSP\PLATE\plate_infer.h
..\..\output\plate_infer.o: D:\keil5\ARM\ARMCC\Bin\..\include\stdint.h
..\..\output\plate_infer.o: ..\..\Drivers\./BSP/PLATE/plate_weights.h
..\..\output\plate_infer.o: D:\keil5\ARM\ARMCC\Bin\..\include\string.h
..\..\output\plate_infer.o: D:\keil5\ARM\ARMCC\Bin\..\include\math.h
